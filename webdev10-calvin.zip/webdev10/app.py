from flask import Flask, redirect, url_for, render_template, session, request 
app = Flask(__name__)

from datetime import timedelta

app.secret_key = "cobacoba"
app.permanent_session_lifetime = timedelta(minutes=5)

@app.route('/', methods=['POST', "GET"])
def home():
    if 'user' in session:
        return redirect(url_for('udahlogin'))
    else:
        return render_template('home.html')


@app.route('/login', methods=['POST', "GET"])
def login():
    if request.method == "POST":
        user = request.form['username']
        passw = request.form['password']
        if user == passw:
            session.permanent = True
            session['user'] = user
            if 'khusus' in session:
                return redirect(url_for('kusus'))
            else:
                return redirect(url_for('home'))
        else:
            return render_template('home.html')
    else:
        return render_template('login.html')


@app.route('/udahlogin', methods=['POST', "GET"])
def udahlogin():
    if 'user' in session:
        return render_template('udahlogin.html')
    else:
        return redirect(url_for('home'))


@app.route('/kusus', methods=['POST', "GET"])
def kusus():
    if 'user' in session:
        return render_template('inikusus.html')
    else:
        session['khusus'] = 'hai'
        return redirect(url_for('login'))


@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('home'))


if __name__ == '__main__':
    app.run()